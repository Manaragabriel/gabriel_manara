<?php return array (
  'contact-form' => 'App\\Http\\Livewire\\ContactForm',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'post.create-posts' => 'App\\Http\\Livewire\\Post\\CreatePosts',
  'post.list-posts' => 'App\\Http\\Livewire\\Post\\ListPosts',
  'site.contact-form' => 'App\\Http\\Livewire\\Site\\ContactForm',
  'user.list-users' => 'App\\Http\\Livewire\\User\\ListUsers',
);